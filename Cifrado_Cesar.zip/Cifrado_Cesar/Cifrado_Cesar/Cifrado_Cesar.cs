﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cifrado_Cesar
{
    class Cifrado_Cesar
    {
        public static void Main(string[] args)
        {
            int op = 1,res;
            while (op < 5)
            {
                Console.WriteLine();
                Console.WriteLine(" ENCRIPTACION USANDO EL CIFRADO CESAR EN EL LENGUAJE C#");
                Console.WriteLine("\n"+" Para cifrar marque    [1]\n"+ " Para descifrar marque [2]\n" +" Para ver el key       [3]\n"+" Para Salir marque     [4]\n");
                res = Convert.ToInt32(Console.ReadLine());
                op=res;
                Cifrado_Cesar cift = new Cifrado_Cesar();
                if (res == 1)
                {
                    cift.cifrado();
                }
                if (res == 2)
                {
                    cift.descifrar();
                }
                if (res == 3)
                {
                    cift.key();
                }
                if (res == 4)
                {
                    Console.In.Close();
                }
            }
        }

        public void cifrado()
        {
            int b, j;
            Console.WriteLine("Introdusca la cadena a cifrar: ");
            string cad = Console.ReadLine();
            j = cad.Length;
            char[] ch = new char[j];
            Console.WriteLine("El cifrado es: ");
            for (int i = 0; i < j; i++)
            {
                b = (int)cad[i];
                ch[i] = (char)(b + 3);
                Console.Write(ch[i]);

            }
            Console.ReadLine();
        }
        public void descifrar()
        {
            int b, j;
            Console.WriteLine("Introdusca la cadena a descifrar");
            string cad = Console.ReadLine();
            j = cad.Length;
            char[] ch = new char[j];
            Console.WriteLine("El cifrado es:");
            for (int i = 0; i < j; i++) 
            {
                b = (int)cad[i];
                ch[i]=(char)(b - 3);
                Console.Write(ch[i]);
            }
            Console.WriteLine();
        }
        public void key()
        {
            Console.WriteLine();
            Console.WriteLine("El desplazamiento del cifrado es de 3");
            string cad = Console.ReadLine();
            Console.WriteLine();
        }

    }
}
